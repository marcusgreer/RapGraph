#Marcus Greer+ Section P + TP1.py

###################
#Twitter API
###################
#inspired by the code on the twitter API Tweepy's website, this code takes all
#texts that are related to 2pac and prints them.
from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener

ckey = 'bmz3jbgy6THJ5TD5I3xBxRaec'
csecret = 'OTxmfO2jNc6KqPJeiIcfIvnlmzQgjJS3oqLm6Nwuag9GnY6wID'
atoken = '61327408-6JWhryRxaGXfmTwXvKSnMH8MvnftMLcbqP70nI8QO'
asecret = 'CeBxRayK6tKLkjOtbZ5lhEX1j7eTMeJ9T552pd7v80SBz'

class listener(StreamListener):
    def on_data(self, data):
        try:
            tweet = data.split(',"text":"')[1].split('","source"')[0]
            print tweet
            #the following code is not actually dead code, It's purpose is to 
            #save all tweets related to a certain topic in a text or csv file:

            # saveFile = open('Tupac.txt','a')
            # saveFile.write(tweet)
            # saveFile.write('\n')
            # saveFile.close()
            return True
        except BaseException, e:
            print 'failed on_data', str(e)
            time.sleep(5)

    def on_error(self, status):
        print status

auth = OAuthHandler(ckey, csecret)
auth.set_access_token(atoken, asecret)
twitterStream = Stream(auth, listener())
# twitterStream.filter(track=['2Pac','Tupac','Shakur'])

####################
#Python Data Scraper
####################




#####################
#Accessing Data
#####################
#Once the data is scraped from the internet, it will be written to a local file 
#The following code will be used create a rapper class



class Rapper(object):
    def __init__(self, name, lyrics, imageFile=None):
        self.name = name
        self.lyrics = lyricDict
        self.imageFile = imageFile
        #for visual components:
        self.r = 15

    def draw(self,canvas,cx,cy):
        self.x = cx
        self.y = cy
        canvas.create_oval(cx-r,cy-r,cx+r,cx+r,outline='red')
        canvas.create_text(cx,cy,text=self.name)


import os
import contextlib
import csv

def getData():
    with open('rappers.csv','rt') as fileIn:
        with open('rappers.txt','wt') as fileOut:
            for line in fileIn:
                for x in ["'",'"','(',')']:
                    line=line.replace(x,'')
                fileOut.write(line)

def createRapperObjects():
    filename = 'rappers.txt'
    with open(filename,'rt') as infile:
        rappers = []
        for row in csv.DictReader(infile):
            rappers.append(Rapper(row['Name'],row['Lyrics']))
    return rappers

getData()
print createRapperObjects()





#################################
#checking for uniqueness in data
#################################

MF_lyrics = '''I got this girl and she wants me to duke her
I told her I'd come scoop her around 8, she said "Super!"
That sounds great, shorty girl's a trooper
No matter what I need her to do, she be like "Super!"
Own his own throne, the boss like King Koopa
On the microphone he flossed the ring "Super!"
Average emcees is like a TV blooper
MF DOOM, he's like D.B. Cooper
Out with the moolah, I let her get a outfit
Just to cool her off she said peoples ain't about shit
I wonder if she meant it, I doubt it
The way it be in her mouth she can't live without it
And can't live with this, handle your business
Villain'll stay on a scandalous ho's shit list
One pack of cookies please, Mr. Hooper
It's fun smacking rookies, he is the "Super!"
Look like a black wookie when he let his beard grow
Weirdo, brown skin'ded always kept his hair low
Rumor has it it's a S-Curl accident
DOOM was always known to keep the best girls' backs bent
Some say it's the eyes, some say the accent
A lot of guys wonder where they stacks went
'''


kendrick_lyrics='''
Thank you
Sitting in the studio thinking about what mood would go
Right now, freestyle or write down, whatever
It still'll come up clever
I just need to free to my thoughts, and Lord knows that I know better
But I ain't perfect, and I ain't seen too many churches
Or know them testament verses
You should either hear me now or go deaf
Or end up dead, die trying and know death
Might end up dead, swallow blood, swallow my breath
Fuck a funeral, just make sure you pay my music respect (people)
I mean that from the bottom of my heart
You see my art, is all I have
And victory tastes sweet, even when the enemy can throw salt
Still knock them out the park like a fucking tow car
Let bygones be bygones but where I'm from
We buy guns and more guns, to give to the young
I'm living the life of a people trapped people
Inside the system, all you envision is trap peoples
My uncle doing life, inside prison he wasn't wrapped too tight
He told me to rap about life, not rap peoples
That's why I'm shaking my head when you rap dissin'
My stomach start turning, my nerves get the twitching
'''

def getLyrics(lyrics):
    lyrics = lyrics.split()
    unique = []
    for lyric in lyrics:
        if ',' in lyric:
            unique.append(lyric[:-1].lower())
        else: unique.append(lyric.lower())
    return unique

kendrickWords = getLyrics(kendrick_lyrics)
print 'Kendrick:',len(set(kendrickWords))*100.0/len(kendrickWords)
MFWords = getLyrics(MF_lyrics)
print 'DOOM:',len(set(MFWords))*100.0/len(MFWords)


uniqueKendrick = set(kendrickWords)-set(MFWords)
uniqueMF = set(MFWords)-set(kendrickWords)
print uniqueKendrick, '\n',len(uniqueKendrick)
print uniqueMF, '\n',len(uniqueMF)

#########
#Display
#########
from Tkinter import *
root = Tk()
swidth = 1300
sheight = 800
canvas = Canvas(root, width=swidth, height=sheight, bg = 'black')
#canvas.create_rectangle(0,0,swidth,sheight,fill='black')
canvas.create_text(swidth/2,sheight/4,fill = 'yellow', text ='Rap Graph', 
    font ='Helvetica 75 bold')
def buttonOne():
    print "Go to Popularity vs. Literal Diversity Graph"

def buttonTwo():
    print 'Go to Influence Graph'

def buttonThree():
    print 'Go to Tag Graph'

button1 = Button(root,text="Popularity vs. Literal Diversity",command=buttonOne)
button2 = Button(root,text="Influence Graph",command=buttonTwo)
button3 = Button(root,text='Tag Graph', command= buttonThree)

button3.pack(side = BOTTOM)
button2.pack(side = BOTTOM)
button1.pack(side = BOTTOM)

canvas.pack()
root.mainloop()

##########
#Tag Cloud
##########

#From http://stackoverflow.com/questions/18974437/how-to-build-a-clean-word-cloud-using-pytagcloud-without-a-crowded-image-pytho

# from pytagcloud import create_tag_image, make_tags
# from pytagcloud.lang.counter import get_tag_counts

# YOUR_TEXT = "A tag cloud is a visual representation for text data, typically\
# used to depict keyword metadata on websites, or to visualize free form text."

# tags = make_tags(get_tag_counts(YOUR_TEXT), maxsize=120)

# create_tag_image(tags, 'cloud_large.png', size=(900, 600), fontname='Lobster')

#####################
#Questions:
#####################
# How do I display the images of the rappers cropped in a circle?
# How do I switch from display to display when I have several opperable frames?
# Dictionary of lyrics and date?
# save an image file location in the csv?


